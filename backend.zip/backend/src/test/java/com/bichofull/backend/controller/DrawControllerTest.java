package com.bichofull.backend.controller;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DrawControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @Order(1)
    @DisplayName("📋 Teste 1: Listar sorteios")
    public void testListarSorteios() throws Exception {
        System.out.println("\n🔵 Testando GET /api/draws...");
        
        mockMvc.perform(get("/api/draws"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"));
        
        System.out.println("✅ Listagem de sorteios funcionou!");
    }

    @Test
    @Order(2)
    @DisplayName("🔍 Teste 2: Buscar sorteio inexistente - deve retornar 404")
    public void testBuscarSorteioInexistente() throws Exception {
        System.out.println("\n🔵 Testando GET /api/draws/9999...");
        
        mockMvc.perform(get("/api/draws/{id}", 9999))
                .andExpect(status().isNotFound());
        
        System.out.println("✅ Busca por sorteio inexistente retornou 404!");
    }
}