package com.bichofull.backend.service;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class UserServiceTest {

    @Autowired
    private UserService userService;

    @Test
    @Order(1)
    @DisplayName("✅ Teste 1: Verificar se service foi injetado")
    public void testServiceInjection() {
        System.out.println("\n🔵 Testando injeção do UserService...");
        
        assertNotNull(userService, "UserService não deveria ser nulo");
        
        System.out.println("✅ UserService injetado com sucesso!");
    }
}