package com.bichofull.backend.service;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BetServiceTest {

    @Autowired
    private BetService betService;

    @Test
    @Order(1)
    @DisplayName("✅ Teste 1: Verificar se BetService foi injetado")
    public void testServiceInjection() {
        System.out.println("\n🔵 Testando injeção do BetService...");
        
        assertNotNull(betService, "BetService não deveria ser nulo");
        
        System.out.println("✅ BetService injetado com sucesso!");
    }

    @Test
    @Order(2)
    @DisplayName("📝 Teste 2: Verificar se service tem métodos básicos")
    public void testServiceMethods() {
        System.out.println("\n🔵 Verificando métodos do BetService...");
        
        // Teste simples - só verifica se o service não é nulo
        assertNotNull(betService);
        
        System.out.println("✅ BetService está disponível para uso!");
    }
}