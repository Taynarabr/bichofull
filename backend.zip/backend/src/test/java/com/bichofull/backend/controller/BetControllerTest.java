package com.bichofull.backend.controller;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BetControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @Order(1)
    @DisplayName("📋 Teste 1: Listar apostas - deve retornar 200")
    public void testListarApostas() throws Exception {
        System.out.println("\n🔵 Testando GET /api/bets...");
        
        mockMvc.perform(get("/api/bets"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"));
        
        System.out.println("✅ Listagem de apostas funcionou!");
    }

    @Test
    @Order(2)
    @DisplayName("🔍 Teste 2: Buscar aposta inexistente - deve retornar 404")
    public void testBuscarApostaInexistente() throws Exception {
        System.out.println("\n🔵 Testando GET /api/bets/9999...");
        
        mockMvc.perform(get("/api/bets/{id}", 9999))
                .andExpect(status().isNotFound());
        
        System.out.println("✅ Busca por aposta inexistente retornou 404!");
    }
}