package com.bichofull.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoApplicationTests {

    @Test
    void contextLoads() {
        System.out.println("🎉 MEU PRIMEIRO TESTE FUNCIONOU!");
    }
}