package com.bichofull.backend.controller;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AnimalControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @Order(1)
    @DisplayName("📋 Teste 1: Tentar listar animais - deve retornar 404 (endpoint não existe)")
    public void testListarAnimais() throws Exception {
        System.out.println("\n🔵 Testando GET /api/animais...");
        
        mockMvc.perform(get("/api/animais"))
                .andExpect(status().isNotFound());
        
        System.out.println("✅ Endpoint /api/animais não existe (retornou 404)");
    }
}